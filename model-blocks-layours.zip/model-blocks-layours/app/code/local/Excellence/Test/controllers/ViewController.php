<?php
class Excellence_Test_ViewController extends Mage_Core_Controller_Front_Action
{
    public function deteleAction()
    {
        $this->loadLayout();            
        $this->renderLayout();  
    }
}