<?php
class Excellence_Test_View_IndexController extends Mage_Core_Controller_Front_Action
{
    public function xyzAction()
    {
        $this->loadLayout();            
        $this->renderLayout();  
    }
}