<?php
class Excellence_Test_User_ViewController extends Mage_Core_Controller_Front_Action
{
    public function historyAction()
    {
        $this->loadLayout();            
        $this->renderLayout();  
    }
}