<?php
class Excellence_Test_Block_Test extends Mage_Core_Block_Template
{
    public function getContent()
    {
        return "Hello World";
    }
}